let pressStartTime = 0;
let currentBitPos = 0;
let bitsSaved = [0, 0, 0, 0, 0, 0, 0, 0];
let tabAscii = [];

const specialCharts = [
  { dec: 0, sym: "NUL" },
  { dec: 1, sym: "SOH" },
  { dec: 2, sym: "STX" },
  { dec: 3, sym: "ETX" },
  { dec: 4, sym: "EOT" },
  { dec: 5, sym: "ENQ" },
  { dec: 6, sym: "ACK" },
  { dec: 7, sym: "BEL" },
  { dec: 8, sym: "BS" },
  { dec: 9, sym: "HT" },
  { dec: 10, sym: "LF" },
  { dec: 11, sym: "VT" },
  { dec: 12, sym: "FF" },
  { dec: 13, sym: "CR" },
  { dec: 14, sym: "SO" },
  { dec: 15, sym: "SI" },
  { dec: 16, sym: "DLE" },
  { dec: 17, sym: "DC1" },
  { dec: 18, sym: "DC2" },
  { dec: 19, sym: "DC3" },
  { dec: 20, sym: "DC4" },
  { dec: 21, sym: "NAK" },
  { dec: 22, sym: "SYN" },
  { dec: 23, sym: "ETB" },
  { dec: 24, sym: "CAN" },
  { dec: 25, sym: "EM" },
  { dec: 26, sym: "SUB" },
  { dec: 27, sym: "ESC" },
  { dec: 28, sym: "FS" },
  { dec: 29, sym: "GS" },
  { dec: 30, sym: "RS" },
  { dec: 31, sym: "US" },
  { dec: 32, sym: "SP" },
  { dec: 160, sym: "NBSP" },
  { dec: 173, sym: "SHY" },
];

function checkChart(asciiChar) {
  let textChar = "";
  for (let i = 0; i < specialCharts.length; i++) {
    if (asciiChar == specialCharts[i].dec) {
      textChar = specialCharts[i].sym;
      if (asciiChar == 2) {
        textChar = textChar + " (caractère de début)";
        return textChar;
      } else if (textChar == "EOT") {
        textChar = textChar + " (caractère de fin)";
        return textChar;
      } else {
        textChar = textChar + " (caractère spécial)";
        return textChar;
      }
    }
  }
  textChar = String.fromCharCode(asciiChar);
  return textChar;
}

const bitShow = document.getElementById("bitsSaved");
const bitCount = document.getElementById("bitCount");
const charAscii = document.getElementById("charAscii");
const char = document.getElementById("char");

async function playSound(telegraphAudio) {
  telegraphAudio.currentTime = 0;
  try {
    await telegraphAudio.play();
  } catch (error) {
    console.error("Erreur lors de la lecture audio :", error);
  }
}

function stopSound(telegraphAudio) {
  telegraphAudio.pause();
}

function stopTimer() {
  const pressDuration = Date.now() - pressStartTime; // Calcule la durée
  return pressDuration;
}

function startTimer() {
  pressStartTime = Date.now();
}

async function changeToDown(telegraphButton, telegraphAudio) {
  telegraphButton.style.backgroundImage = "url('media/telegraph_down.png')";

  await playSound(telegraphAudio);
}

function sampleBit(timePressed) {
  /* TODO : A compléter */
  if (timePressed < 200) {
    return 0;
  } else {
    return 1;
  }

  //return currentBit;
}

function changeToUp(telegraphButton, telegraphAudio) {
  telegraphButton.style.backgroundImage = "url('media/telegraph_up.png')";

  stopSound(telegraphAudio);
}

function accumulateBits(newBit) {
  /* TODO : A compléter */
  if (currentBitPos < 8) {
    bitsSaved[currentBitPos] = newBit;
    currentBitPos++;

    bitShow.innerText += newBit + " "; // Montre les bits
    bitCount.innerText = currentBitPos;
  }

  if (currentBitPos === 8) {
    const asciiChar = calculateAscii(bitsSaved);
    console.log("ASCII Character:", asciiChar);
    console.log("The Character:", String.fromCharCode(asciiChar)); // Converti les décimal en Symbole ASCII
    charAscii.innerText = asciiChar;
    char.innerText = checkChart(asciiChar);

    sendCharacter(asciiChar);

    tabAscii.push(asciiChar); // Add the character to tabAscii array
    console.log("Complete ASCII Message:", tabAscii.join(""));

    clearBitsSaved(); // Clear pour prochain bit
    currentBitPos = 0; // Remet à 0 le nombre de bits

    bitShow.innerText = ""; //Remet à rien les bits
    bitCount.innerText = "";
  }
}

function clearAll() {
  clearBitsSaved(); // Clear pour prochain bit
  currentBitPos = 0; // Remet à 0 le nombre de bits
  charAscii.innerText = "";
  char.innerText = "";
  bitShow.innerText = ""; //Remet à rien les bits
  bitCount.innerText = "";
}

function calculateAscii(bitsArray) {
  /* TODO : A compléter */
  let asciiValue = 0;
  for (let i = 0; i < bitsArray.length; i++) {
    asciiValue += bitsArray[i] * Math.pow(2, 7 - i); // Converti la ligne de binaire en décimal
  }
  return asciiValue;
}

if (typeof module !== "undefined" && typeof module.exports !== "undefined") {
  module.exports = {
    playSound,
    stopSound,
    changeToDown,
    changeToUp,
  };
}

// Ne pas modifier ces deux fonctions
function getBitsSaved() {
  return bitsSaved;
}

function clearBitsSaved() {
  bitsSaved = [0, 0, 0, 0, 0, 0, 0, 0];
}
